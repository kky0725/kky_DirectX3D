#include "Framework.h"
#include "TextureScene.h"

TextureScene::TextureScene()
{
}

TextureScene::~TextureScene()
{
}

void TextureScene::Update()
{
}

void TextureScene::PreRender()
{
}

void TextureScene::Render()
{
}

void TextureScene::PostRender()
{
}

