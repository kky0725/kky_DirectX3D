#include "Framework.h"
#include "Quad.h"

Quad::Quad()
{
}

Quad::~Quad()
{
}

void Quad::Update()
{
}

void Quad::Render()
{
}
