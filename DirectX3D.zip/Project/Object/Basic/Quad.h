#pragma once
class Quad : public Transform
{
public:
	Quad();
	virtual ~Quad();

	virtual void Update();
	void Render();

private:


};